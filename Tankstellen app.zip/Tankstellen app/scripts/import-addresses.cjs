'use strict';
// node scripts/import-addresses.cjs /path/to/ADRESSENOGD.geojson
// Download-URL und Lizenz stehen in README.md und addresses.json.
const fs = require('node:fs');
const path = require('node:path');
const { normalize } = require('../addresses.cjs');
const source = 'https://data.wien.gv.at/daten/geo?service=WFS&version=1.1.0&request=GetFeature&typeName=ogdwien:ADRESSENOGD&outputFormat=json&srsName=EPSG:4326&CQL_FILTER=GEB_BEZIRK%3D%2721%27&propertyName=SHAPE,GEB_BEZIRK,NAME_STR,ONR_VON,ONR_BIS,NAME_ONR,GEB_STATUS_KURZTEXT,ABLAUFDATUM';
const data = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
if (!Array.isArray(data.features) || data.features.length !== Number(data.numberMatched ?? data.totalFeatures)) {
    throw new Error('Der Download ist unvollständig. Keine Adressdaten ersetzt.');
}
const addresses = new Map();
for (const feature of data.features) {
    const p = feature.properties;
    if (String(p.GEB_BEZIRK) !== '21' || p.GEB_STATUS_KURZTEXT !== 'definitiv' || p.ABLAUFDATUM) continue;
    const street = p.NAME_STR?.trim();
    const number = p.NAME_ONR?.trim();
    const [lon, lat] = feature.geometry?.type === 'Point' ? feature.geometry.coordinates : [];
    if (!street || !/^\d+[a-z]?(?:[-/]\d+[a-z]?)?$/i.test(number ?? '')
        || !Number.isFinite(lon) || !Number.isFinite(lat) || lon < 16 || lon > 17 || lat < 48 || lat > 49) continue;
    const key = `${normalize(street)}|${normalize(number)}`;
    // Mehrere Gebäudeeingänge: ein reproduzierbarer Adresspunkt pro Hausadresse.
    if (!addresses.has(key)) addresses.set(key, [street, number, lon, lat]);
}
const rows = [...addresses.values()].sort((a, b) => a[0].localeCompare(b[0], 'de-AT') || a[1].localeCompare(b[1], 'de-AT', { numeric: true }));
if (rows.length < 10000) throw new Error('Unerwartet wenige Adressen. Keine Adressdaten ersetzt.');
const output = { source, attribution: 'Stadt Wien – data.wien.gv.at', license: 'CC BY 4.0',
    importedAt: new Date().toISOString().slice(0, 10), sourceTimestamp: data.timeStamp,
    district: 21, columns: ['street', 'number', 'longitude', 'latitude'], rows };
fs.writeFileSync(path.join(__dirname, '../addresses.json'), JSON.stringify(output) + '\n');
console.log(`${rows.length} definitive Hausadressen in Floridsdorf importiert.`);
