'use strict';

const normalize = value => String(value ?? '').toLocaleLowerCase('de-AT').replace(/ß/g, 'ss')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, '').replace(/[–—]/g, '-');

function parseAddress(query) {
    const [first, ...locality] = query.trim().split(',');
    if (locality.length && !/^(?:(?:1210\s+)?(?:wien|vienna)|1210)$/i.test(locality.join(',').trim())) return null;
    const part = first.trim().replace(/\s+(?:1210\s+)?(?:Wien|Vienna)$/i, '');
    const match = part.match(/^(.+?)\s*(\d+[a-zA-Z]?(?:\s*[-–—/]\s*\d+[a-zA-Z]?)?)$/);
    return match ? { street: match[1].trim(), number: match[2].replace(/\s+/g, '').replace(/[–—]/g, '-') } : null;
}

// Ein Bindestrich bezeichnet einen Bereich; ein Schrägstrich keine Zahlenfolge.
// Auf ausdrücklichen Wunsch zählen auch gerade Zahlen in Bereichen wie 1–5.
function numberMatches(requested, stored) {
    if (normalize(requested) === normalize(stored)) return true;
    const range = normalize(stored).match(/^(\d+)-(\d+)$/);
    if (!range || !/^\d+$/.test(requested)) return false;
    const n = Number(requested);
    return n >= Number(range[1]) && n <= Number(range[2]);
}

function createAddressIndex(rows) {
    const byStreet = new Map();
    for (const [street, number, longitude, latitude] of rows) {
        if (!street || !number || !Number.isFinite(latitude) || !Number.isFinite(longitude)
            || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) continue;
        const key = normalize(street);
        if (!byStreet.has(key)) byStreet.set(key, []);
        byStreet.get(key).push({ street, number, longitude, latitude });
    }
    return query => {
        const parsed = parseAddress(query);
        if (!parsed) return [];
        const street = byStreet.get(normalize(parsed.street)) ?? [];
        const exact = street.filter(row => normalize(row.number) === normalize(parsed.number));
        return exact.length ? exact : street.filter(row => numberMatches(parsed.number, row.number));
    };
}

module.exports = { normalize, parseAddress, numberMatches, createAddressIndex };
