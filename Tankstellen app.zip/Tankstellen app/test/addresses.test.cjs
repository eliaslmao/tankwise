'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { numberMatches, parseAddress, createAddressIndex } = require('../addresses.cjs');
const { createRoutingService } = require('../routing.cjs');
const data = require('../addresses.json');

test('inclusive ranges accept every integer, but not suffixes, slash numbers or out-of-range numbers', () => {
    for (const number of ['1', '2', '3', '4', '5']) assert.ok(numberMatches(number, '1–5'));
    for (const number of ['0', '6', '2a', '2/1', '2-3']) assert.equal(numberMatches(number, '1-5'), false);
    assert.equal(numberMatches('2', '1/3'), false);
    assert.ok(numberMatches('105B', '105b'));
    assert.equal(numberMatches('105', '105b'), false);
    assert.equal(parseAddress('Siemensstraße 1, 1220 Wien'), null);
});

test('exact house numbers take priority over overlapping ranges', () => {
    const find = createAddressIndex([['Testgasse', '1-5', 16.4, 48.27], ['Testgasse', '2', 16.41, 48.28]]);
    assert.equal(find('Testgasse 2')[0].number, '2');
    assert.equal(find('Testgasse 4')[0].number, '1-5');
});

test('all imported preview addresses resolve in the same index; planned Brünner Straße 420 is excluded', () => {
    const find = createAddressIndex(data.rows);
    for (const [street, number] of data.rows) {
        assert.ok(find(`${street} ${number}, 1210 Wien`).length, `${street} ${number}`);
    }
    assert.ok(find('Siemensstraße 1, 1210 Wien').length);
    assert.equal(find('Brünnerstraße 420').length, 0);
});

test('official address and range searches succeed without external requests and retain the stored range label', async () => {
    const service = createRoutingService({ stations: [], addressRows: [
        ['Siemensstraße', '1', 16.40931229, 48.27658208], ['Testgasse', '1-5', 16.4, 48.27]
    ], fetchImpl: async () => { throw Error('Unexpected external request'); } });
    assert.equal((await service.geocode('Siemensstrasse 1')).candidates[0].label, 'Siemensstraße 1, 1210 Wien');
    for (const n of [1, 2, 3, 4, 5]) {
        const result = await service.geocode(`Testgasse ${n}`);
        assert.equal(result.candidates[0].label, 'Testgasse 1-5, 1210 Wien');
        assert.equal(result.candidates[0].addressConfirmed, true);
    }
});

test('OSM fallback discovers and confirms stored ranges after an unsuccessful single-number search', async () => {
    const queries = [];
    const service = createRoutingService({ stations: [], addressRows: [], schedule: fn => fn(), fetchImpl: async url => {
        queries.push(url.searchParams.get('q'));
        return { ok: true, json: async () => queries.length === 1 ? [] : [{
            lat: '48.27', lon: '16.4', address: { country_code: 'at', city: 'Wien',
                suburb: 'Floridsdorf', road: 'Testgasse', house_number: '1-3' }
        }] };
    } });
    assert.equal((await service.geocode('Testgasse 2')).candidates[0].label, 'Testgasse 1-3, 1210 Wien');
    assert.deepEqual(queries, ['Testgasse 2', 'Testgasse, 1210 Wien']);
});
